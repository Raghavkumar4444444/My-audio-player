const playlist = ["song1.mp3", "song2.mp3", "song3.mp3"];
      let currentIndex = 0;
      const player = document.getElementById("player");
      const head = document.getElementById("h1");

      function loadSong(index) {
        player.src = playlist[index];
        player.load();
      }

      function btn() {
        loadSong(currentIndex);
        head.style.background = "red";
        player.play();
      }

      function stop() {
        player.pause();
        player.currentTime = 0;
        head.style.background = "#0056b3";
      }

      function next() {
        currentIndex = (currentIndex + 1) % playlist.length;
        btn();
      }

      function prev() {
        currentIndex = (currentIndex - 1 + playlist.length) % playlist.length;
        btn();
      }