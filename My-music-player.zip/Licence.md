Copyright © 2025 [Raghav]

This project is licensed under a custom license:

✔ Allowed:
- View and use the website in browser.

❌ Not allowed:
- Reuse, copy, edit, or distribute the source code.
- Use the project for any commercial purposes.

This is a non-commercial, no-derivatives license.

Contact [raghavchpoali@gmail.com] for permissions.